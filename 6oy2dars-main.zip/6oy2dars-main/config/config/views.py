from django.shortcuts import render
from django.http import HttpRequest
import random

def vazifalar(request: HttpRequest):# 1-vazifa
    mevalar = ["Olma", "Banan", "Shaftoli", "Gilos"]

    # 2-vazifa
    shaxs = {"ism": "Ali", "yosh": 25, "kasb": "Dasturchi"}

    # 3-vazifa
    talabalar = [
        {"ism": "Ali", "ball": 85},
        {"ism": "Vali", "ball": 60},
        {"ism": "Salim", "ball": 90},
    ]
    for talaba in talabalar:
        talaba["status"] = "Otdi" if talaba["ball"] >= 70 else "boshqa topshirish"

    # 4-vazifa
    mahsulotlar = [
        {"nom": "Laptop", "narx": 1500},
        {"nom": "Telefon", "narx": 800},
        {"nom": "Sichqoncha", "narx": 30},
    ]
    for mahsulot in mahsulotlar:
        mahsulot["qimmatmi"] = mahsulot["narx"] > 100

    # 5-vazifa
    sonlar = [42, 10, 3, 98, 55, 1]
    saralangan_sonlar = sorted(sonlar)

    # 6-vazifa
    yuqori_ball_talabalar = [talaba for talaba in talabalar if talaba["ball"] >= 80]

    # 7-vazifa
    sonlarr = sum([4, 8, 15, 16, 23, 42])

    # 8-vazifa
    odamlar = [
        {"ism": "Ali", "yosh": 25},
        {"ism": "Vali", "yosh": 30},
        {"ism": "Salim", "yosh": 28},
    ]
    ortacha_yosh = sum(odam["yosh"] for odam in odamlar) / len(odamlar)

    # 9-vazifa
    eng_katta_son = max([5, 12, 67, 89, 34, 21])

    # 10-vazifa
    mamlakatlar = ["O‘zbekiston", "AQSh", "Rossiya", "Xitoy"]

    # 11-vazifa
    kitoblar = [
        {"nom": "Python Asoslari", "muallif": "Guido Van Rossum"},
        {"nom": "Django Pro", "muallif": "Adrian Holovaty"},
    ]

    # 12-vazifa
    ishchilar = [
        {"ism": "Ali", "maosh": 1200},
        {"ism": "Vali", "maosh": 1500},
        {"ism": "Salim", "maosh": 1800},
    ]
    balondmosh = max(ishchi["maosh"] for ishchi in ishchilar)

    # 13-vazifa
    lotereya_sonlari = sorted(random.sample(range(1, 100), 6))

    # 14-vazifa
    filmlar = [
        {"nom": "Inception", "yil": 2010},
        {"nom": "Interstellar", "yil": 2014},
        {"nom": "The Dark Knight", "yil": 2008},
    ]
    eski_film = min(filmlar, key=lambda f: f["yil"])
    yangi_film = max(filmlar, key=lambda f: f["yil"])

    # 15-vazifa
    odamlar_ismlari = ["Ali", "Muhammad", "Vali", "Olimjon"]
    uzun_ism = max(odamlar_ismlari, key=len)

    context = {
        "mevalar": mevalar,
        "shaxs": shaxs,
        "talabalar": talabalar,
        "mahsulotlar": mahsulotlar,
        "saralangan_sonlar": saralangan_sonlar,
        "yuqori_ball_talabalar": yuqori_ball_talabalar,
        "sonlar_yigindisi": sonlarr,
        "ortacha_yosh": ortacha_yosh,
        "eng_katta_son": eng_katta_son,
        "mamlakatlar": mamlakatlar,
        "kitoblar": kitoblar,
        "ishchilar": ishchilar,
        "eng_yuqori_maosh": balondmosh,
        "lotereya_sonlari": lotereya_sonlari,
        "eng_eski_film": eski_film,
        "eng_yangi_film": yangi_film,
        "eng_uzun_ism": uzun_ism,
    }

    return render(request, "vazifa.html", context)